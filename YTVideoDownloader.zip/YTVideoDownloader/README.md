Hey! My name is Gabriele, and i'm a hobbyist developer from Italy. This is the first real package i share with the world. For any question, tip or whatever it might be, this is my email: 666cristoanticristo@gmail.com.

---------
Man, i just hate websites where  downloading a simple youtube video you have to watch trough 987654 ads, wait 876543 years and get shitty result. So... there you go!

This simple tool will download in your desktop the highest possible resolution of the desired video. That's it!

Have a good one, see ya!
